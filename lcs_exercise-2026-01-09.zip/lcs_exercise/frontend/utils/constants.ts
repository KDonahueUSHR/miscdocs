export const MEMBER_API = process.env.API_URL || "";
